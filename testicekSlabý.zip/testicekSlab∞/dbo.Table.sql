﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [First] NTEXT NULL , 
    [Last] NTEXT NULL , 
    [Phone] NTEXT NULL , 
    [Email] NVARCHAR(50) NULL , 
    [ Birthday] DATETIME NULL
)
